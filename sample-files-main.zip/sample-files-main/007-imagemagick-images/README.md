Generated via [imagemagick](https://legacy.imagemagick.org/Usage/formats/#ps):

```bash
convert -quality 100 * imagemagick-images.pdf
convert -compress none smile.png imagemagick-ASCII85Decode.pdf
convert -compress lzw smile.png imagemagick-lzw.pdf
convert -alpha off -monochrome -compress fax smile.png imagemagick-CCITTFaxDecode.pdf
```
