# PDF Sample Files

This repository provides files for testing software that reads / parses
PDF files.

The `files.json` file contains a list of those PDF files with their metadata.

## Licenses

Every PDF in this repository is under the Creative Commons
Attribution-NonCommercial-NoDerivs License (CC BY-NC-ND).


## Contributions

Please contribute files to fill this repository! Just create a PR with a
PDF file created by you.
