This is a PDF/A-1B compatible document.
