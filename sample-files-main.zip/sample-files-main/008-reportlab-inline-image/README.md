Credits to [Sebastian Krause](https://github.com/sekrause) for [this one](https://github.com/py-pdf/pypdf/pull/331#issuecomment-1093783640)
